Description of the files
a) 'OpenScale_prereq.docx' - Document describing the prerequisites for the workshop and the workshop contents.
b) GermanCreditRisk_v1_spark_MRM_Test.ipynb - Notebook to create the test model (also known as the challenger model)
c) GermanCreditRisk_v2_scikit_MRM_PreProd.ipynb - Notebook to create the pre production model
d) GermanCreditRisk_v2_scikit_MRM_Prod.ipynb - Notebook to create the production model
e) wml_scoring_client.ipynb - Notebook for scoring the model and to make sure records reach OpenScale Payload logging table
f) german_credit_data_biased_test.csv - Test data that would be used for testing the test (challenger) model
g) german_credit_data_biased_test_2.csv - Test data that would be used for testing the pre production model
h) german_credit_data_biased_training.csv - Training data that would be stored to Cloud Object Storage and thereby for used while configuring the subscription.
i) single_record.json - used to enable payload logging of the subscription
j) score_payloads_2.json - handy file, not used for now.
